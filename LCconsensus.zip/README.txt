Consensus locus coeruleus mask accompanying the article "Uncovering the locus coeruleus", Verónica Mäki-Marttunen and Thomas Espeseth.
Contact: makimarttunen.veronica@gmail.com